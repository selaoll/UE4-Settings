Persistent Graphics Settings in UE4
===================================

Fork of [ImpetusGames/UE4-Settings] (https://github.com/ImpetusGames/UE4-Settings) to use it as a UE4 plugin

More information can be found on the [Impetus Games web site](https://impetus-games.com/blog/Persistent-Graphics-Settings-in-UE4).
